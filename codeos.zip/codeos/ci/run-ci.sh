#!/bin/bash
# GitHub Actions 에서 호출: 빌드 → (SHA256, 2GB 이하 조각) → Draft 릴리스 업로드, 결과를 Summary 에 요약
# 필요한 환경변수: PROJ GITHUB_WORKSPACE (+ GH_TOKEN RUN_NUMBER GITHUB_SHA USE_BACKPORTS)
set -uo pipefail
OUT="$GITHUB_WORKSPACE/out"; mkdir -p "$OUT"
SUM="${GITHUB_STEP_SUMMARY:-/dev/null}"

summarize_failure() {
  {
    echo "## ❌ 빌드 실패"
    if [ -f "$OUT/build.log" ]; then
      echo "### 핵심 오류 줄 (자동 추출 — 이 부분만 복사해서 알려 주세요)"
      echo '```'
      grep -nE '(^E: |^dpkg: error|Unable to locate|^FAIL |^NONE |No such file|returned error|[Ee]rror:|lb_[a-z_]+: |E: .*failed)' "$OUT/build.log" | tail -n 40
      echo '```'
      echo "### build.log 마지막 50줄"
      echo '```'; tail -n 50 "$OUT/build.log"; echo '```'
    else
      echo "build.log 가 만들어지지 않았습니다. Docker 실행 단계에서 실패했습니다. 'ISO 빌드' 단계 로그의 마지막 부분을 확인하세요."
    fi
  } >> "$SUM"
}

echo "=== 1) ISO 빌드 ==="
docker run --rm --privileged -e USE_BACKPORTS="${USE_BACKPORTS:-0}" \
  -v "$PROJ":/src:ro -v "$OUT":/out \
  debian:bookworm bash -c "tr -d '\r' < /src/docker-build-inner.sh > /tmp/inner.sh && bash /tmp/inner.sh"
rc=$?
if [ $rc -ne 0 ] || [ ! -f "$OUT/codeos.iso" ]; then
  echo "빌드 실패 (종료코드 $rc)"; summarize_failure; exit 1
fi
ls -lh "$OUT"

echo "=== 2) 설치 못 한 패키지 보고 ==="
if [ -f "$OUT/build.log" ]; then
  {
    echo "### 패키지 설치 보고"
    if grep -qE '^(FAIL|NONE) ' "$OUT/build.log"; then
      echo "아래 패키지는 저장소에 없거나 설치에 실패해서 **빠졌습니다** (나머지는 정상):"
      echo '```'; grep -E '^(FAIL|NONE) ' "$OUT/build.log" | sort -u; echo '```'
    else
      echo "모든 패키지가 정상 설치되었습니다."
    fi
  } >> "$SUM"
fi

echo "=== 3) 조각 나누기 (GitHub 릴리스 파일 2GB 제한) ==="
cd "$OUT" || exit 1
sha256sum codeos.iso > codeos.iso.sha256
split -b 1900M -d -a 2 codeos.iso codeos.iso.part
rm -f codeos.iso
cp "$PROJ/join-iso.bat" .
ls -lh

echo "=== 4) Draft 릴리스 업로드 ==="
TAG="iso-${RUN_NUMBER:-0}"
cat > "$OUT/notes.md" << 'NOTES'
## CodeOS ISO
1. 아래 파일을 **전부** 같은 폴더에 다운로드 (`codeos.iso.part00`, `part01`, … / `codeos.iso.sha256` / `join-iso.bat`)
2. `join-iso.bat` 더블클릭 → `codeos.iso` 생성
3. VirtualBox 에 연결해서 부팅 (사용자 `dev` / 비밀번호 `live`)

⚠️ 이 ISO 에는 Google Chrome 과 VS Code(Microsoft) 가 들어 있습니다. 개인 사용용이며, **Publish 해서 공개하지 마세요** (재배포 라이선스 문제).
NOTES
gh release create "$TAG" --draft --target "${GITHUB_SHA:-main}" --title "CodeOS ISO (build ${RUN_NUMBER:-0})" --notes-file "$OUT/notes.md" \
  || { echo "릴리스 생성 실패"; echo "## ❌ 릴리스 생성 실패 (권한: Settings → Actions → Workflow permissions → Read and write)" >> "$SUM"; exit 1; }
for f in "$OUT"/codeos.iso.part* "$OUT"/codeos.iso.sha256 "$OUT"/join-iso.bat; do
  ok=0
  for i in 1 2 3; do
    if gh release upload "$TAG" "$f" --clobber; then ok=1; break; fi
    echo "업로드 재시도 ($i): $f"; sleep 20
  done
  if [ "$ok" != 1 ]; then echo "## ❌ 업로드 실패: $(basename "$f")" >> "$SUM"; exit 1; fi
done
{
  echo "## ✅ 빌드 완료"
  echo "저장소 → **Releases** 에서 Draft 릴리스 \`$TAG\` 의 파일을 **모두** 내려받고 \`join-iso.bat\` 을 실행하세요."
} >> "$SUM"
