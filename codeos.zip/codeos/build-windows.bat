@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo ===== CodeOS ISO 빌드 (Windows + Docker Desktop) =====
echo.
where docker >nul 2>nul
if errorlevel 1 goto nodocker
docker info >nul 2>nul
if errorlevel 1 goto dockeroff
if not exist out mkdir out
echo 빌드를 시작합니다. 인터넷이 필요하고 40~90분 걸립니다. 창을 닫지 마세요.
echo 최신 커널 없이 빌드하려면 먼저 이 창에서:  set NO_BACKPORTS=1
echo.
docker run --rm --privileged -e NO_BACKPORTS=%NO_BACKPORTS% -v "%cd%":/src:ro -v "%cd%\out":/out debian:bookworm bash -c "tr -d '\r' < /src/docker-build-inner.sh > /tmp/inner.sh && bash /tmp/inner.sh"
if errorlevel 1 goto failed
echo.
echo ===== 완료! ISO 파일: %cd%\out\codeos.iso =====
pause
exit /b 0

:nodocker
echo [오류] Docker 가 설치되어 있지 않습니다.
echo   1) https://www.docker.com/products/docker-desktop 에서 Docker Desktop 설치
echo   2) 설치 후 재부팅, Docker Desktop 실행
echo   3) 이 파일을 다시 더블클릭
pause
exit /b 1

:dockeroff
echo [오류] Docker Desktop 이 실행 중이 아닙니다.
echo   시작 메뉴에서 Docker Desktop 을 실행하고, 고래 아이콘이 "Running" 이 될 때까지 기다린 뒤 다시 실행하세요.
pause
exit /b 1

:failed
echo.
echo [실패] 빌드가 중단되었습니다. 위쪽 메시지의 마지막 50줄을 복사해서 알려 주세요.
echo   (폴더 안에 build.log 가 없다면 위 화면의 오류 메시지가 전부입니다.)
pause
exit /b 1
