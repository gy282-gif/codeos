#!/bin/bash
# Docker 컨테이너(debian:bookworm) 안에서 실행됩니다.
# (build-in-docker.sh / build-windows.bat / GitHub Actions 가 호출)
set -e
export DEBIAN_FRONTEND=noninteractive
# 성공/실패와 관계없이 build.log 를 밖으로 복사 (실패 원인 확인용)
trap 'cp /work/build.log /out/ 2>/dev/null || true' EXIT
apt-get update
apt-get install -y --no-install-recommends live-build debootstrap xorriso \
  syslinux syslinux-utils isolinux syslinux-common mtools dosfstools squashfs-tools \
  grub-pc-bin grub-efi-amd64-bin grub-common cpio zstd ca-certificates curl gnupg fakeroot \
  librsvg2-bin imagemagick
# 윈도우 권한/줄바꿈 문제를 피하려고 컨테이너 내부로 복사해서 빌드
cp -a /src /work && cd /work
# 윈도우에서 압축을 풀면 생기는 CRLF 줄바꿈 제거 (텍스트 파일만; PNG 등 바이너리는 건드리지 않음)
grep -rIl $'\r' . 2>/dev/null | xargs -r sed -i 's/\r$//' || true
chmod +x build.sh auto/* config/hooks/live/*.hook.chroot 2>/dev/null || true
bash ./build.sh
cp codeos.iso /out/
echo "== 완료: out/codeos.iso =="
