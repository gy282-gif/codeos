# CodeOS — 윈도우처럼 생긴, 코딩에 최적화된 Debian Linux

겉은 윈도우(가운데 정렬 작업 표시줄, 시작 메뉴, 시스템 트레이, 바탕화면 아이콘, Win 단축키), 속은 **100% Debian 12 GNU/Linux** 입니다.
Microsoft의 로고/아이콘 등 자산은 쓰지 않았습니다. (`desktop-preview.png`, `login-preview.png` 는 디자인 모형)

> ⚠️ 이 프로젝트는 설계/검증 환경에 인터넷이 없어서 **실제 ISO 빌드와 부팅은 아직 해 보지 못했습니다.**
> 스크립트 문법, JSON/XML, 생성 로직, `codeos` 명령은 직접 실행해 검증했습니다. 아래 "문제가 생기면" 을 참고하세요.

## 1. ISO 만들기

### GitHub 클라우드가 대신 빌드 — 내 PC에 아무것도 설치하지 않음 (가장 쉬움)
1. https://github.com 로그인 → 우상단 **+ → New repository** → 이름 `codeos`, **Public** 선택 → Create repository
2. 만들어진 화면의 **uploading an existing file** 클릭 → **`codeos.zip` 을 압축 풀지 말고 그대로** 끌어다 놓기 → **Commit changes**
3. **Add file → Create new file** → 파일 이름 칸에 `.github/workflows/build-iso.yml` 입력(슬래시를 치면 폴더가 자동 생성) →
   내용 칸에 `build-iso.yml` 의 전체 내용을 붙여넣기 → **Commit changes**
4. 상단 **Actions** 탭 → 왼쪽 **Build CodeOS ISO** → **Run workflow** → 초록 버튼
5. 60~120분 뒤 초록 체크가 뜨면 저장소의 **Releases** → *Draft* 릴리스의 파일을 **전부** 한 폴더에 다운로드
6. **`join-iso.bat` 더블클릭** → `codeos.iso` 완성 (SHA256 해시도 자동 출력)
- 실패하면 Actions 실행 화면 하단 **Summary** 에 **"핵심 오류 줄"** 이 자동으로 추려 나옵니다. 그 부분만 복사해서 알려 주세요. 전체 로그는 같은 화면 맨 아래 *Artifacts → build-log* 에서 받을 수 있어요.
- 신형 노트북 Wi-Fi 용 최신 커널이 필요하면 Run workflow 창에서 *최신 커널/펌웨어(backports) 사용* 을 체크하세요. (기본은 꺼짐 — 처음엔 안정판으로 빌드)
- 코드를 고친 뒤에는 **`codeos.zip` 만 같은 이름으로 다시 업로드**하면 됩니다 (빌드 로직이 zip 안의 `ci/run-ci.sh` 에 있음).
- ISO 는 **Draft(비공개) 릴리스**로만 올라갑니다. Chrome/VS Code 재배포 문제가 있으니 **Publish 하지 마세요.**
- Public 저장소는 Actions 시간이 무료/무제한이고 서버 사양도 더 좋습니다. (소스에는 비밀 정보가 없습니다.)

### Windows (cmd / PowerShell / 탐색기) — 권장
1. **Docker Desktop** 설치 (https://www.docker.com/products/docker-desktop) → 재부팅 → Docker Desktop 실행, 고래 아이콘이 *Running* 이 될 때까지 대기
2. `codeos.zip` 을 **짧은 영문 경로**에 압축 해제 (예: `C:\codeos`). 드라이브 루트(`C:\`) 자체나 한글/공백이 많은 깊은 경로는 피하세요.
3. **`build-windows.bat` 을 더블클릭** (또는 cmd 에서 `build-windows.bat`)
4. 40~90분 후 `out\codeos.iso` 생성
> ⚠️ cmd 에서 `./build-in-docker.sh` 를 치면 `'.'은(는) 내부 또는 외부 명령...` 오류가 납니다. `.sh` 는 리눅스/맥/WSL 용이에요.
> 최신 커널/펌웨어(신형 노트북 Wi-Fi 용)를 쓰려면 cmd 에서 `set USE_BACKPORTS=1` 입력 후 `build-windows.bat` 실행.
> Docker Desktop 은 C: 드라이브에 약 25GB 이상 여유가 필요합니다 (설정 → Resources → Disk image size 확인).

### Linux / macOS / WSL2
```bash
./build-in-docker.sh                  # 결과: ./out/codeos.iso
USE_BACKPORTS=1 ./build-in-docker.sh   # 최신 커널/펌웨어(backports) 사용
```
- WSL2 는 `/mnt/c/...` 가 아닌 **리눅스 파일시스템**(예: `~/codeos`)에서 실행하세요.
- Debian 12/Ubuntu 에서 Docker 없이 직접: `sudo apt install live-build debootstrap xorriso syslinux-utils isolinux mtools squashfs-tools zstd librsvg2-bin imagemagick && sudo ./build.sh`

필요: 인터넷, 여유 디스크 25GB 이상, 시간 40~90분. 결과 ISO 는 약 6~8GB.

## 2. VirtualBox 설정
| 항목 | 값 |
|---|---|
| 유형/버전 | Linux / Debian (64-bit) |
| 메모리 / CPU | 4096MB 이상 / 2~4코어 |
| 비디오 | 그래픽 컨트롤러 **VMSVGA**, 비디오 메모리 128MB (검은 화면이면 3D 가속 끄기) |
| 저장소 | `codeos.iso` 연결. 설치할 거면 가상 디스크 40GB 이상 |

부팅하면 **로그인 화면**: 사용자 `dev` / 비밀번호 `live` (sudo 무비밀번호).
라이브 모드는 재부팅하면 변경이 사라집니다 → 바탕화면 **"CodeOS 설치"** 로 디스크에 설치하세요.

## 3. 이번에 추가/개선된 것

### 하드웨어 (Wi-Fi 등)
- **NetworkManager + 트레이 아이콘**, Wi-Fi 절전 해제(끊김 예방), 한국 규제 도메인(KR, 5GHz/6GHz 채널)
- **펌웨어:** Intel(iwlwifi), Realtek, Atheros, Broadcom(brcm80211), MediaTek 등 misc, AMD 그래픽, 사운드(SOF), 마이크로코드(Intel/AMD)
- **최신 노트북 지원:** 커널 + 펌웨어를 `bookworm-backports` 에서 설치 (Wi-Fi 6/6E/7, 신형 GPU 대응)
- 블루투스(Blueman), 오디오(PulseAudio+pavucontrol), 프린터(CUPS + HP/Samsung 드라이버), LTE 모뎀, VPN, NTFS/exFAT(윈도우 디스크), MTP(안드로이드)
- `codeos doctor` 가 인터넷/Wi-Fi/블루투스/Docker/GPU 를 점검하고 원인을 알려 줍니다.
- Broadcom 구형 칩 / NVIDIA 전용 드라이버는 빌드에 넣으면 위험해서 **필요할 때 설치** 합니다: `sudo apt install broadcom-sta-dkms`, `codeos nvidia`

### Chrome 기본 브라우저
- Google Chrome(공식 저장소) 설치 + 기본 브라우저 설정 + 작업 표시줄 고정. 업데이트는 `apt` 로 자동. 설치가 실패하면 Firefox 가 기본이 됩니다.
- 개발 북마크 바(GitHub, MDN, DevDocs, Python 문서 등), 기본 브라우저 팝업/원격 측정 끔
- Firefox 도 함께 설치돼 있습니다.

### 디자인
- **가운데 정렬 작업 표시줄(윈도우 11 스타일)** + 자체 제작 시작 버튼 로고, 2줄 시계(`오후 03:20 / 2026-10-23`), 오른쪽 끝 "바탕화면 보기"
- **CodeOS 테마**(Arc 기반, 포인트색 #0a84ff, 둥근 모서리, 반투명 어두운 패널), Papirus-Dark 아이콘, DMZ 커서, Inter + JetBrains Mono 폰트(한글은 Noto CJK 자동 대체)
- 배경화면 4종(midnight/bloom/aurora/sunset), 다크 기본 → `codeos theme light` 로 전환
- **터미널:** One Dark 색, 반투명, 무제한 스크롤 / **VS Code:** One Dark Pro + Material 아이콘
- 로그인 화면(반투명 카드, 둥근 아바타, 파란 버튼, 한국어 시계), 부팅 메뉴 이미지, 설치 프로그램 로고
- **환영 페이지**(`/usr/share/codeos/welcome.html`): 첫 로그인 때 자동으로 열리고, 바탕화면 "CodeOS 시작하기" 로 다시 열기

### 코딩 꿀팁 기능
| 기능 | 사용법 |
|---|---|
| **프로젝트 생성기** | `codeos new python\|node\|web\|c\|cpp\|go\|java 이름` → git, .gitignore, 가상환경, 테스트, VS Code 설정까지 |
| **Git/SSH 한방 설정** | `codeos git-setup` (이름/이메일 + GitHub용 SSH 키 생성·클립보드 복사) |
| **상태 점검 / 청소 / 업데이트** | `codeos doctor` · `codeos clean` · `codeos update` · `codeos ports` |
| **꿀팁 48개** | 터미널을 열 때마다 하나씩 (`codeos tips off` 로 끄기, `codeos tips all` 전체 보기) |
| **치트시트 6종** | `codeos cheat git\|vim\|tmux\|docker\|linux\|regex` |
| **셸 강화** | 컬러 프롬프트(가상환경/git 브랜치·상태/실패 코드), fzf(Ctrl+R/T), zoxide(`z`), direnv, 대형 히스토리, `mkcd` `extract` `killport` `bak` `up` `please` |
| **Git 별칭** | `git st` `lg` `undo` `wip` `cleanup` `ca` …, 자동 upstream, rerere, zdiff3, 전역 .gitignore |
| **윈도우 단축키** | Win+E 탐색기 · Win+D 바탕화면 · Win+L 잠금 · Win+R 실행 · Win+←/→ 창 분할 · Ctrl+Shift+Esc 작업 관리자 |
| **개발 단축키** | **Win+C** VS Code · **Win+Enter** 터미널 · **Win+B** 브라우저 · **Win+Shift+S** 캡처(Flameshot) |
| **VS Code** | **확장 50여 개 사전 설치**(Python 전부 + Jupyter + C/C++ + Go + Rust + Java + Docker + GitLens + Prettier 등), 저장 시 포맷/import 정렬, 한국어 팩 |
| **파이썬** | numpy/pandas/matplotlib/scipy/Jupyter/pytest 설치됨, `mkvenv` 로 가상환경 |
| **파일 관리자** | 우클릭 → "VS Code 로 폴더/파일 열기", "전체 경로 복사" |
| **성능** | inotify 감시 한도 상향(대형 프로젝트), zram 압축 스왑, earlyoom, 파일 핸들 상향, 부팅 지연 제거, 키 반복 속도 빠르게, SSD trim |
| **권한** | 로그인 시 자동으로 docker / dialout(시리얼·아두이노) / plugdev(USB) 그룹에 추가 |
| **도구** | Docker, gcc/clang/CMake/Ninja/gdb/lldb/valgrind, Node, Java+Maven, Go, SQLite(+GUI), ripgrep/fd/bat/jq/httpie/tmux/btop/meld/tig/ncdu/hyperfine/pre-commit …, Timeshift(스냅샷 백업), GParted |
| **한글 입력** | ibus-hangul, Hangul 키 / Shift+Space 전환 |

## 4. 버그 예방을 위해 고친 것
- 빌드 중 **실패해도 계속 진행**하도록: 필수 패키지는 15개로 최소화(`core.list.chroot`), 나머지 ~160개는 "일괄 설치 → 실패하면 하나씩" 방식(`packages-extra.txt`, `optional-packages.txt`). 설치 못 한 패키지는 Summary 에 보고됨. VS Code/Chrome/확장 설치는 개별 실패 허용 + 시간 제한 + 깨진 dpkg 상태 자동 복구
- 최신 커널(backports)은 **기본 꺼짐** (첫 빌드 성공 우선)
- `apt-get update` 없이 설치해서 실패하던 훅 수정, `/etc/issue` 이스케이프 오류 수정, Docker 가 라이브(overlay) 루트에서 불안정한 점 안내
- 테마를 파일 복사+sed 하던 방식(Arc 의 `gtk.gresource` 때문에 적용 안 될 수 있음) → `@import` 래퍼 방식으로 교체
- gschema override(키 하나만 틀려도 조용히 무시) → **dconf 시스템 DB** 로 이전, 브라우저/커서 등은 설치 결과를 보고 훅이 동적으로 결정
- Chrome 이 저장소를 중복 추가하는 문제, VS Code 저장소 `Signed-By` 충돌 방지
- 프로젝트 생성기: 만든 직후 `pytest` 가 없던 문제 수정 (requirements 에 pytest 포함, 오프라인이면 안내)
- 빌드 디스크 용량 사전 경고, backports 끄는 스위치(`NO_BACKPORTS=1`)

## 5. 문제가 생기면
| 증상 | 해결 |
|---|---|
| 윈도우에서 `'.'은(는) 내부 또는 외부 명령...` | `.sh` 가 아니라 **`build-windows.bat`** 을 실행 |
| 빌드가 중단됨 | GitHub: Actions 실행 화면 Summary 의 "핵심 오류 줄" 복사. 로컬: `out/build.log` 마지막 50줄 |
| 패키지가 빠짐 | 빠진 패키지는 빌드 Summary 에 나열됩니다. 이름 확인 후 `etc/codeos/packages-extra.txt` 수정 |
| VS Code 확장 일부 없음 | 첫 로그인 때 자동 보충. 수동: `codeos ext` |
| Wi-Fi 안 잡힘 | `codeos doctor` → 안내대로 (Broadcom/rfkill 등) |
| 작업 표시줄 모양/고정 앱이 기대와 다름 | 앱 우클릭 → "작업 표시줄에 고정". 스크린샷을 보내 주시면 CSS 를 맞춰 드려요 |
| 부팅이 안 됨(실제 PC) | BIOS 에서 Secure Boot 끄기, USB 는 Rufus **DD 모드** 로 굽기 |

## 6. 커스터마이징 위치
| 바꾸고 싶은 것 | 파일 |
|---|---|
| 설치할 프로그램 | `config/includes.chroot/etc/codeos/packages-extra.txt` · `optional-packages.txt` (실패 허용) / `config/package-lists/core.list.chroot` (필수, 최소) |
| 작업 표시줄/테마/단축키/터미널/한글 입력 | `config/includes.chroot/etc/dconf/db/local.d/00-codeos` |
| 테마 색/모양 | `config/hooks/live/0050-codeos-theme.hook.chroot` |
| 배경화면 | `config/includes.chroot/usr/share/backgrounds/codeos/` |
| VS Code 설정 / 확장 | `…/etc/skel/.config/Code/User/settings.json` · `…/etc/codeos/vscode-extensions.txt` |
| 로그인 화면 | `…/etc/lightdm/` · `…/usr/share/themes/CodeOS-Login/gtk-3.0/gtk.css` |
| 셸 별칭/프롬프트 | `…/etc/codeos/bashrc` |
| 팁 / 치트시트 / 환영 페이지 | `…/usr/share/codeos/` |
| 언어/키보드/사용자명/자동 로그인 | `auto/config` 의 `--bootappend-live` |
| 작업 표시줄을 왼쪽 정렬(윈도우 10 스타일)로 | dconf `enabled-applets` 의 `center` → `left` |
