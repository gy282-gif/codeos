# tmux 치트시트 (prefix = Ctrl+B)
    tmux new -s 이름     세션 만들기      tmux a -t 이름   다시 붙기     tmux ls  목록
    prefix d             분리(세션은 계속 실행)
    prefix c / n / p     새 창 / 다음 / 이전
    prefix %  /  "       좌우 분할 / 상하 분할
    prefix 방향키        칸 이동          prefix z   칸 확대/복귀
    prefix [             스크롤/복사 모드 (q 로 종료)
    prefix x             칸 닫기          prefix ,   창 이름 바꾸기
