# 리눅스 명령 치트시트
## 파일
    ls -alh / tree -L 2 / cd - / pwd
    cp -r 원본 대상 / mv / rm -r (복구 불가!) / mkdir -p a/b/c
    find . -name "*.py"  →  fd -e py       grep -rn "문자열" .  →  rg "문자열"
    chmod +x 파일 / chmod 755 / chown 사용자: 파일
    du -sh * | sort -h / df -h / ncdu
## 보기/가공
    cat / less / head -n 20 / tail -f 로그
    wc -l / sort | uniq -c | sort -nr / cut -d, -f1 / awk '{print $1}' / sed 's/a/b/g'
## 프로세스/네트워크
    ps aux | grep 이름 / kill -9 PID / killall 이름 / btop
    ss -tulpn (codeos ports) / curl -I URL / ping 주소 / ip a
## 패키지 (Debian)
    sudo apt update / sudo apt install 이름 / apt search 단어 / sudo apt remove 이름
## 시스템
    systemctl status|start|stop|restart 서비스    journalctl -u 서비스 -f
    sudo !!   (직전 명령을 sudo 로)      lsblk   블록 장치    lsusb / lspci
