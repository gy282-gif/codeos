# Git 치트시트
## 시작
    git init -b main            새 저장소
    git clone <url>             복제
    git config --global user.name "이름"
## 매일 쓰는 것
    git st                      상태(짧게)
    git add -p                  조각 단위로 골라 담기
    git cm "메시지"             커밋
    git lg                      그래프 로그
    git diff --staged           담은 변경 보기
## 브랜치
    git sw -c 새브랜치          만들고 이동
    git sw -                    직전 브랜치로
    git merge 브랜치 / git rebase main
    git cleanup                 병합된 브랜치 삭제
## 되돌리기
    git undo                    마지막 커밋 취소(변경 유지)
    git restore 파일            작업 중 변경 버리기
    git restore --staged 파일   add 취소
    git reflog                  사라진 커밋도 찾아 복구
    git revert <커밋>           안전하게 되돌리는 새 커밋
## 임시 저장 / 찾기
    git stash -u / git stash pop
    git bisect start / good / bad    버그 커밋 찾기
    git log -S"문자열"          그 문자열이 바뀐 커밋 찾기
    git blame 파일
## 원격
    git push                    (처음부터 upstream 자동 설정됨)
    git pull / git fetch --prune
    gh pr create / gh pr checkout 123 / gh repo clone 사용자/저장소
