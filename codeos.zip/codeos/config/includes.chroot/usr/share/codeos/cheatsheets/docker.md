# Docker 치트시트
    docker run -it --rm -p 8080:80 -v "$PWD":/app 이미지      실행(포트/볼륨 연결)
    docker ps -a / docker images
    docker logs -f 이름              로그 따라가기
    docker exec -it 이름 bash        컨테이너 안으로
    docker stop 이름 / docker rm 이름 / docker rmi 이미지
    docker build -t 이름:태그 .
    docker-compose up -d / down / logs -f / ps
    docker system df                 용량 확인
    docker system prune -a           안 쓰는 것 전부 정리 (주의)
# 라이브(USB) 모드에서는 root 파일시스템 특성상 Docker 가 느릴 수 있어요. 설치 후 사용을 권장합니다.
