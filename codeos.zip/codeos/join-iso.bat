@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo ===== CodeOS ISO 조각 합치기 =====
echo.
if not exist codeos.iso.part00 goto nopart
echo 합치는 중... (수 분 걸릴 수 있습니다. 창을 닫지 마세요)
copy /b codeos.iso.part* codeos.iso >nul
if errorlevel 1 goto fail
echo.
echo 완료: %cd%\codeos.iso
echo.
echo [무결성 확인] 아래 두 값이 같아야 합니다.
echo --- 내 파일 ---
certutil -hashfile codeos.iso SHA256 | findstr /v "hash CertUtil"
echo --- 원본 (codeos.iso.sha256) ---
type codeos.iso.sha256
echo.
pause
exit /b 0

:nopart
echo [오류] codeos.iso.part00 파일이 없습니다.
echo   릴리스에서 받은 모든 파일(part00, part01, ... / sha256 / 이 bat)을 같은 폴더에 넣고 다시 실행하세요.
pause
exit /b 1

:fail
echo [오류] 합치기에 실패했습니다. 디스크 여유 공간(ISO 크기의 2배 이상)과 part 파일 누락 여부를 확인하세요.
pause
exit /b 1
