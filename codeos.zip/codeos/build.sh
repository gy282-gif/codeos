#!/bin/bash
# Debian 12(bookworm) 환경에서 root 로 실행 (보통은 docker-build-inner.sh 가 대신 호출)
#   USE_BACKPORTS=1 ./build.sh   -> 최신 커널/펌웨어(backports) 사용 (최신 노트북 Wi-Fi 용). 기본은 안정판 커널.
set -euo pipefail
cd "$(dirname "$0")"
[ "$(id -u)" = 0 ] || { echo "root 권한이 필요합니다: sudo ./build.sh"; exit 1; }

chmod +x auto/* config/hooks/live/*.hook.chroot 2>/dev/null || true
chmod +x config/includes.chroot/usr/local/bin/* 2>/dev/null || true
if [ "${USE_BACKPORTS:-0}" = 1 ]; then
  echo ">> backports(최신 커널/펌웨어) 사용"
else
  echo ">> 안정판 커널 사용 (backports 제외)"
  rm -f config/archives/bookworm-backports.*
fi

lb clean --purge || true
./auto/config

# 부팅 메뉴 이미지 교체 (꾸미기용: 실패해도 빌드는 계속)
png_width() { od -An -tu1 -j16 -N4 "$1" | awk '{print $1*16777216+$2*65536+$3*256+$4}'; }
if [ -d /usr/share/live/build/bootloaders ] && [ -f branding/splash-640x480.png ]; then
  {
    mkdir -p config/bootloaders
    cp -a /usr/share/live/build/bootloaders/. config/bootloaders/
    find config/bootloaders -type f -name 'splash*.png' | while read -r f; do
      w=$(png_width "$f" 2>/dev/null || echo 0)
      if [ "${w:-0}" -ge 1280 ]; then cp branding/splash-1920x1080.png "$f"; else cp branding/splash-640x480.png "$f"; fi
    done
  } || echo "WARN: 부팅 이미지 교체 실패(무시)"
fi

lb build 2>&1 | tee build.log
ISO=$(ls -1 ./*.iso | head -n1)
mv "$ISO" codeos.iso
echo "완료: $(pwd)/codeos.iso ($(du -h codeos.iso | cut -f1))"
