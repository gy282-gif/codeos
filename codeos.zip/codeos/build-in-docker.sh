#!/bin/bash
# Linux / macOS / WSL2 용.  결과물: ./out/codeos.iso
# (윈도우 cmd/PowerShell 에서는 build-windows.bat 을 사용하세요)
#   USE_BACKPORTS=1 ./build-in-docker.sh   (최신 커널/펌웨어 사용)
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p out
FREE_KB=$(df -k . | awk 'NR==2{print $4}')
[ "${FREE_KB:-0}" -gt 25000000 ] || echo "경고: 여유 공간이 25GB 미만입니다. 빌드가 실패할 수 있어요."
docker run --rm --privileged -e USE_BACKPORTS="${USE_BACKPORTS:-0}" \
  -v "$PWD":/src:ro -v "$PWD/out":/out \
  debian:bookworm bash -c "tr -d '\r' < /src/docker-build-inner.sh > /tmp/inner.sh && bash /tmp/inner.sh"
echo "ISO 위치: $PWD/out/codeos.iso"
